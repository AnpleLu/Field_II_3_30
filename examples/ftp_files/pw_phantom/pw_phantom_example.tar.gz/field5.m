%  Start up the Field simulation system

p=path;
path(p, 'C:\USERS\JAJ\PROGRAMS\FIELD_II\M_FILES_PC');

field_init(0)

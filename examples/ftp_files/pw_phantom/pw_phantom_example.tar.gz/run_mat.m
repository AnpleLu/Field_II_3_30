%  Field has to be called before the sim_pw_multi since
%  Matlab 5 checks the names in the file before executing

field
sim_pw_multi

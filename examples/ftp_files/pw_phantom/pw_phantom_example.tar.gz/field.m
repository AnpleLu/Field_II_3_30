%  Start up the Field simulation system

p=path;
path(p, '/home/jaj/programs/field_II/M_files');

field_init(0)
